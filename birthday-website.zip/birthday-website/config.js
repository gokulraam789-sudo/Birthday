/* ============================================================
   EDIT THIS FILE to customise the website. No other file needs
   to change for normal edits.
   Use {name} anywhere to insert the name typed on the login page.
   ============================================================ */
const CONFIG = {
  // Password (DD/MM/YYYY). Typing 25-10-2005 or 25102005 also works.
  password: "25/10/2005",

  // Your name, shown at the bottom of the page and at the end of the letter
  from: "Gokul",

  // The short wish on the home page
  wish: "Wishing you a day as bright, warm and wonderful as you make every day for the people around you. May this year bring you every little joy you've been quietly hoping for.",

  // The letter (opens when she taps the button). One string = one paragraph.
  letterGreeting: "Dear {name},",
  letter: [
    "Happy birthday! I wanted to make something that says what I don't say often enough: I'm really glad you're my sister.",
    "Thank you for the laughs, the fights we forgot by dinner, and every time you had my back without being asked. Growing up with you made my world louder, funnier and a lot more fun.",
    "I hope this year is gentle with you and generous too. May your dreams find their way to you, and may you always remember how loved you are.",
    "Now go enjoy your cake. And yes, you get the biggest slice."
  ],
  letterClosing: "Always with you,",

  // The gift reveal
  surpriseTitle: "Your birthday gift 🎁",
  surpriseText: "Your gift is a day where you're the boss: pick the food, pick the movie, and I'm treating you. Tell me when you're ready to cash it in!",
  // Optional: put a photo in the "images" folder and write its path here, e.g. "images/us.jpg"
  surprisePhoto: ""
};
